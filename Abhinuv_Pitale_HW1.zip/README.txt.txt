Use the following locations to run and test the main codes in the homework:-
\hw1\prob_edge\evaluateSegmentation.m

\hw1\prob_pyramids\runThis.m

\hw1\prob_hybrid\runThis.m
\hw1\prob_hybrid\Question 1\Einstein_Marilyn_01.m
\hw1\prob_hybrid\Question 1\Cst_Dog_02.m
\hw1\prob_hybrid\Question 1\Bicycle_MotorCycle.m
\hw1\prob_hybrid\Question 1\failed_case.m