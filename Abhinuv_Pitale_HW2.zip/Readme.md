Readme:
Following are the functions that can be used for testing the code developed for the various questions.
These files are all in the root directory.

Part1:
a. getKeyPoints
b. featureTracking

Part2:
runThis

Part3:
runThis

Graduate Points:
1
a. featureTrackingCoarseToFine AND getKeypointsCoarse
b. featureTrackingOpticalFlow

2
runThis AND checkBestFit

3
a. runThis
b. solved on paper.