This is the renamed version of the York Urban database, used for the experiments.
(original can be downloaded from http://www.elderlab.yorku.ca/YorkUrbanDB/)

For each image two additional files are provided: one with horizon (a, b, c coefficients for equation ax+by+x = 0) 
as well as the file with zenith coordinates 